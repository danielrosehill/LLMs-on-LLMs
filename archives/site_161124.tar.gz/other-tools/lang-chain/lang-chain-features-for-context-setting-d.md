# Prompt

One facet of LLM usage that can be frustrating is providing the LLMs with context. I'm wondering does Lang Chain have any elements for creating a rich personal context about your life and projects so that you don't need to keep feeding that to models?






